# Sponsors 🤑

### Gold Sponsors

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset=".assets/gold-sponsors[dark].svg">
    <source media="(prefers-color-scheme: light)" srcset=".assets/gold-sponsors.svg">
    <img src=".assets/gold-sponsors.svg">
  </picture>
</p>

### Silver Sponsors

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset=".assets/silver-sponsors[dark].svg">
    <source media="(prefers-color-scheme: light)" srcset=".assets/silver-sponsors.svg">
    <img src=".assets/silver-sponsors.svg">
  </picture>
</p>

### Bronze Sponsors

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset=".assets/bronze-sponsors[dark].svg">
    <source media="(prefers-color-scheme: light)" srcset=".assets/bronze-sponsors.svg">
    <img src=".assets/bronze-sponsors.svg">
  </picture>
</p>

<br />
<br />
<br />

## Individuals ☕

Ian Cylkowski
